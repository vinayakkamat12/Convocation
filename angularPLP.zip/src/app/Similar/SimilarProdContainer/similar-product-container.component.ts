import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-similar-product-container',
  templateUrl: './similar-product-container.component.html',
  styleUrls: ['./similar-product-container.component.css']
})
export class SimilarProductContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
