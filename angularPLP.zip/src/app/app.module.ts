import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SimilarProductComponent } from './Similar/SimilarProd/similar-product.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SimilarProductContainerComponent } from './Similar/SimilarProdContainer/similar-product-container.component';



@NgModule({
  declarations: [
    AppComponent,
    SimilarProductComponent,
    SimilarProductContainerComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
